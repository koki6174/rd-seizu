# Repeated timeout postmortem

Observed:
- official attempt 1: timed out after 1800s
- official attempt 2: timed out after 1800s

The second attempt had already removed Profit YoY and used a simpler 3-factor design, so synthetic arithmetic benchmarks were not predictive of official wall time.

Updated deployment rule:
1. avoid all fins_statements reads
2. avoid listed_info
3. use a single public feature parquet
4. keep path discovery bounded; never recursive-glob the filesystem
5. avoid joins and pandas rolling/groupby apply
6. let the official evaluator perform daily ranking instead of duplicating it in predict()

Primary submission uses only price/volume and a NumPy rolling calculation.

If this version also times out, use submission_ultra_static.py as a runtime diagnostic. That fallback deliberately sacrifices alpha and should only be used to test whether the environment can execute a minimal user submission at all.
