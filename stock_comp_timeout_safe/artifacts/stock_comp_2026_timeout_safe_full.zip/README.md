# Stock Competition 2026 - timeout-safe revision

Date: 2026-10-04

The previous 4-factor and reduced 3-factor official submissions both exceeded 1800 seconds.

Primary deployable strategy:
- reads only prices_daily_quotes_valid.parquet
- projects Date, Code, Close, Volume only
- no financial parquet
- no listed_info
- no target/raw_target
- no merge_asof
- no ML/GPU/network
- no pandas groupby.apply/groupby.rolling
- 60-day mean log dollar-volume computed with NumPy cumulative sums
- signal = negative rolling average log dollar volume

The goal of this revision is to remove the observed timeout failure mode while retaining a low-turnover illiquidity/smallness proxy.

Known competition-sample evidence: standalone illiquidity was reported at Valid Sharpe +0.57. The exact signal here is a simplified one-file proxy, so that reported value is not claimed as this submission's score.

Files:
- submission.py: recommended timeout-safe submission
- submission_ultra_static.py: diagnostic fallback only
